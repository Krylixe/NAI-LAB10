from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path('admin/', admin.site.urls),
    path('offer-mng/', include('oferta_panel.urls')),
    path('offer/', include('oferta_publiczna.urls')),
    path('', include('register.urls')),
]