from django.urls import path
from . import views

urlpatterns = [
    path('', views.panel_glowny, name='offer-mng-home'),
    path('categ-lst/', views.lista_kategorii, name='offer-mng-categ-lst'),
    path('course-lst/', views.lista_szkolen, name='offer-mng-course-lst'),
    path('categ-add/', views.dodaj_kategorie, name='offer-mng-categ-add'),
    path('course-add/', views.dodaj_szkolenie, name='offer-mng-course-add'),
]