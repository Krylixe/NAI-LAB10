from django.apps import AppConfig


class OfertaPanelConfig(AppConfig):
    name = 'oferta_panel'
