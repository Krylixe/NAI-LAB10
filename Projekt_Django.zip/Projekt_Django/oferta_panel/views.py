from django.shortcuts import render
from django.contrib.auth.decorators import login_required

@login_required(login_url='/admin/login/')
def panel_glowny(request):
    return render(request, 'oferta_panel/panel.html')

@login_required(login_url='/admin/login/')
def lista_kategorii(request):
    return render(request, 'oferta_panel/categ_lst.html')

@login_required(login_url='/admin/login/')
def lista_szkolen(request):
    return render(request, 'oferta_panel/course_lst.html')

@login_required(login_url='/admin/login/')
def dodaj_kategorie(request):
    return render(request, 'oferta_panel/categ_add.html')

@login_required(login_url='/admin/login/')
def dodaj_szkolenie(request):
    return render(request, 'oferta_panel/course_add.html')