from django.contrib import admin
from .models import Kategoria, Szkolenie

admin.site.register(Kategoria)
admin.site.register(Szkolenie)