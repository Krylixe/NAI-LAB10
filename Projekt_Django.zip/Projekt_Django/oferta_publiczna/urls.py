from django.urls import path
from . import views

urlpatterns = [
    path('', views.kategorie, name='offer-home'),
    path('<str:kategoria>/', views.lista_szkolen, name='offer-category'),
    path('<str:kateg>/course/', views.opis_szkolenia, name='offer-course'),
]