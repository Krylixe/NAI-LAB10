from django.apps import AppConfig


class OfertaPublicznaConfig(AppConfig):
    name = 'oferta_publiczna'
