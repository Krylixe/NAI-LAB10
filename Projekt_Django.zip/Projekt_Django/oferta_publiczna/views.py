from django.shortcuts import render
from .models import Kategoria, Szkolenie

def kategorie(request):
    # Pobieramy z bazy tylko kategorie, które mają zaznaczone "publikuj" i sortujemy je
    lista_kategorii = Kategoria.objects.filter(publikuj=True).order_by('kolejnosc')
    return render(request, 'oferta_publiczna/kategorie.html', {'kategorie': lista_kategorii})

def lista_szkolen(request, kategoria):
    lista_szkolen = Szkolenie.objects.filter(kategoria__nazwa__icontains=kategoria, publikuj=True).order_by('kolejnosc')[:10]
    return render(request, 'oferta_publiczna/lista_szkolen.html', {
        'kategoria_nazwa': kategoria,
        'szkolenia': lista_szkolen
    })

def opis_szkolenia(request, kateg):
    return render(request, 'oferta_publiczna/opis_szkolenia.html', {'kateg': kateg})