from django.db import models

class Kategoria(models.Model):
    publikuj = models.BooleanField(default=True)
    kolejnosc = models.IntegerField(default=0)
    kategoria_nadrzedna = models.ForeignKey('self', on_delete=models.SET_NULL, null=True, blank=True)
    nazwa = models.CharField(max_length=255)

    def __str__(self):
        return self.nazwa

class Szkolenie(models.Model):
    kategoria = models.ForeignKey(Kategoria, on_delete=models.CASCADE)
    publikuj = models.BooleanField(default=True)
    kolejnosc = models.IntegerField(default=0)
    liczba_godzin = models.IntegerField()
    numer = models.CharField(max_length=50)
    cena = models.DecimalField(max_digits=10, decimal_places=2)
    tytul = models.CharField(max_length=255)
    opis = models.TextField()

    def __str__(self):
        return self.tytul