from django.shortcuts import render
from oferta_publiczna.models import Szkolenie
from .models import Rejestracja

def strona_glowna(request):
    return render(request, 'register/strona_glowna.html')

def rejestracja(request):
    szkolenia = Szkolenie.objects.filter(publikuj=True)
    wiadomosc = ""

    if request.method == 'POST':
        szkolenie_id = request.POST.get('szkolenie')
        imie = request.POST.get('imie')
        nazwisko = request.POST.get('nazwisko')
        telefon = request.POST.get('telefon')
        email = request.POST.get('email')
        zgoda = request.POST.get('zgoda_rodo') == 'on'

        if szkolenie_id and imie and nazwisko and email:
            wybrane_szkolenie = Szkolenie.objects.get(id=szkolenie_id)
            Rejestracja.objects.create(
                szkolenie=wybrane_szkolenie,
                imie=imie,
                nazwisko=nazwisko,
                telefon=telefon,
                email=email,
                zgoda_rodo=zgoda
            )
            wiadomosc = "Zgłoszenie zostało wysłane pomyślnie!"

    return render(request, 'register/rejestracja.html', {
        'szkolenia': szkolenia, 
        'wiadomosc': wiadomosc
    })

# Poniżej zostaw ewentualne funkcje api_form_templates itd.

from django.http import JsonResponse, HttpResponse
from django.core import serializers
import json

# --- ENDPOINTY API ---

def api_form_templates(request):
    # Prosty JSON udający definicję formularza
    data = {"form": "Szablon", "pola": ["imie", "nazwisko", "email"]}
    return JsonResponse(data)

def api_message_templates(request):
    # Zwraca kod HTML zgodnie z wymaganiami
    return HttpResponse("<div><h2>Potwierdzenie rejestracji</h2><p>Dziękujemy za zapis!</p></div>")

def api_categories(request):
    # Kategorie zapisane "na sztywno" w kodzie (wymóg z instrukcji)
    kategorie = [
        {"id": 1, "nazwa": "Informatyka"},
        {"id": 2, "nazwa": "Zarządzanie"},
        {"id": 3, "nazwa": "Języki obce"}
    ]
    return JsonResponse(kategorie, safe=False)

def api_courses(request):
    # Serializacja danych z bazy (tabela Szkolenie)
    szkolenia = Szkolenie.objects.all()
    data = serializers.serialize('json', szkolenia)
    return HttpResponse(data, content_type='application/json')

def api_registers(request):
    # Serializacja danych z bazy (tabela Rejestracja)
    rejestracje = Rejestracja.objects.all()
    data = serializers.serialize('json', rejestracje)
    return HttpResponse(data, content_type='application/json')

def api_register_get(request, id):
    # Serializacja jednej konkretnej rejestracji na podstawie ID
    rejestracja = Rejestracja.objects.filter(id=id)
    data = serializers.serialize('json', rejestracja)
    return HttpResponse(data, content_type='application/json')