from django.urls import path
from . import views

urlpatterns = [
    # Strona główna
    path('', views.strona_glowna, name='home'),
    
    # Widok formularza HTML
    path('register/', views.rejestracja, name='register-view'),
    
    # Endpointy API
    path('formTemplates/', views.api_form_templates, name='api-form-templates'),
    path('messageTemplates/', views.api_message_templates, name='api-message-templates'),
    path('categories/', views.api_categories, name='api-categories'),
    path('courses/', views.api_courses, name='api-courses'),
    path('registers/', views.api_registers, name='api-registers'),
    path('register/<int:id>/', views.api_register_get, name='api-register-get'),
]