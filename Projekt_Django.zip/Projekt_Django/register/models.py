from django.db import models
from oferta_publiczna.models import Szkolenie

class Rejestracja(models.Model):
    szkolenie = models.ForeignKey(Szkolenie, on_delete=models.CASCADE)
    zgoda_rodo = models.BooleanField(default=False)
    status = models.CharField(max_length=50, default='Oczekująca')
    data_godzina_rejestracji = models.DateTimeField(auto_now_add=True)
    imie = models.CharField(max_length=100)
    nazwisko = models.CharField(max_length=100)
    telefon = models.CharField(max_length=20)
    email = models.EmailField()

    def __str__(self):
        return f"{self.imie} {self.nazwisko} - {self.szkolenie.tytul}"